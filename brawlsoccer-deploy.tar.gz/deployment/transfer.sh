#!/bin/bash
# Script de transfert des fichiers vers le serveur
# transfer.sh - À exécuter depuis votre machine locale

set -e

# Configuration - MODIFIEZ CES VALEURS
SERVER_USER="root"  # ou votre utilisateur avec sudo
SERVER_HOST="votre-serveur.com"
SERVER_PORT="22"
APP_DIR="/var/www/brawlsoccer"

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')]${NC} $1"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
    exit 1
}

# Vérifier que nous sommes dans le bon répertoire
if [ ! -f "server.js" ] || [ ! -f "package.json" ]; then
    error "Ce script doit être exécuté depuis la racine du projet BrawlSoccer"
fi

log "📡 Transfert vers le serveur $SERVER_HOST..."

# 1. Compiler l'application localement
log "🔨 Compilation locale..."
if [ -f "build.js" ]; then
    npm run build
    success "Application compilée"
fi

# 2. Créer une archive des fichiers nécessaires
log "📦 Création de l'archive..."
TEMP_DIR=$(mktemp -d)
ARCHIVE_NAME="brawlsoccer-$(date +%Y%m%d_%H%M%S).tar.gz"

# Copier les fichiers nécessaires
cp -r dist/* $TEMP_DIR/ 2>/dev/null || cp -r public $TEMP_DIR/
cp server.js package.json $TEMP_DIR/
cp -r deployment $TEMP_DIR/ 2>/dev/null || true

# Si il y a un dossier medias, l'inclure
if [ -d "public/medias" ]; then
    mkdir -p $TEMP_DIR/public
    cp -r public/medias $TEMP_DIR/public/
fi

# Créer l'archive
cd $TEMP_DIR
tar -czf /tmp/$ARCHIVE_NAME .
cd - > /dev/null

success "Archive créée: /tmp/$ARCHIVE_NAME"

# 3. Transférer l'archive
log "📤 Transfert de l'archive vers le serveur..."
scp -P $SERVER_PORT /tmp/$ARCHIVE_NAME $SERVER_USER@$SERVER_HOST:/tmp/

# 4. Se connecter au serveur et déployer
log "🚀 Déploiement sur le serveur..."

ssh -p $SERVER_PORT $SERVER_USER@$SERVER_HOST << EOF
    set -e
    
    # Créer le répertoire de destination
    mkdir -p $APP_DIR
    
    # Extraire l'archive
    cd $APP_DIR
    tar -xzf /tmp/$ARCHIVE_NAME
    
    # Copier la configuration de production
    if [ -f "deployment/.env.production" ]; then
        cp deployment/.env.production .env
    fi
    
    # Rendre le script de déploiement exécutable
    if [ -f "deployment/deploy.sh" ]; then
        chmod +x deployment/deploy.sh
        echo "✅ Fichiers transférés avec succès"
        echo "🔄 Pour terminer l'installation, exécutez:"
        echo "   cd $APP_DIR && sudo ./deployment/deploy.sh"
    else
        echo "⚠️  Script de déploiement non trouvé"
        echo "📋 Installation manuelle nécessaire"
    fi
    
    # Nettoyer
    rm -f /tmp/$ARCHIVE_NAME
EOF

# Nettoyer localement
rm -f /tmp/$ARCHIVE_NAME
rm -rf $TEMP_DIR

success "🎉 Transfert terminé!"

echo ""
log "📋 Prochaines étapes sur le serveur:"
echo "   1. Connectez-vous: ssh $SERVER_USER@$SERVER_HOST"
echo "   2. Allez dans le dossier: cd $APP_DIR"
echo "   3. Lancez le déploiement: sudo ./deployment/deploy.sh"
echo ""
warning "N'oubliez pas de modifier la configuration Nginx avec votre domaine!"